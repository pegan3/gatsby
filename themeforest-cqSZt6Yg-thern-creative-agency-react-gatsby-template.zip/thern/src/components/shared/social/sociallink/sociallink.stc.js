import styled from 'styled-components';

export const SocialLinkWrap = styled.a ``
    