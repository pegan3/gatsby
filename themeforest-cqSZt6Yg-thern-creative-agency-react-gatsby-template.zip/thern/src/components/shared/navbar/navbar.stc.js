import styled from 'styled-components';

export const NavbarWrap = styled.ul `
    margin: 0;
    padding: 0;
`; 