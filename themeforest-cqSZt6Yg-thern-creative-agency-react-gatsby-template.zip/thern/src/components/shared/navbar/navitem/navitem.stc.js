import styled from 'styled-components';

export const NavItemWrap = styled.li `
    list-style: none;
    position: relative;
`;
 