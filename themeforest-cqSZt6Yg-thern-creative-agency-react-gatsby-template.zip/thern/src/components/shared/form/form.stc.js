import styled from 'styled-components';

export const FormWrap = styled.form `

`;