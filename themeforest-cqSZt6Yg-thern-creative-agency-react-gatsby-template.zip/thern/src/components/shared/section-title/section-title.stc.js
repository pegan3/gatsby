import styled from 'styled-components';
 
export const TitleWrapper = styled.div `
    line-height: 1;
`;

