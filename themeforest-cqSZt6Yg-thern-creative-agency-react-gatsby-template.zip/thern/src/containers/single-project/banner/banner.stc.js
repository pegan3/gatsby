import styled from 'styled-components';

export const BannerWrap = styled.div `
    .gatsby-image-wrapper{
        z-index: -1;
    }
`;